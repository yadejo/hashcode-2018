﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Hashcode.Terminal.Models
{
    public class Board
    {
        private int[,] map;
        private ValuesMap _valueMap;
        public Car[] cars;
        private Ride[] rides;
        public Dictionary<int, List<Ride>> handled { get; }
        public Board(ValuesMap valueMap)
        {
            _valueMap = valueMap;
            map = new int[valueMap.rows, valueMap.columns];
            cars = new Car[valueMap.vihicules];
            handled = new Dictionary<int, List<Ride>>();
            for (var i= 0; i < cars.Length; i++)
            {
                cars[i] = new Car();
                cars[i].Id = i;
            }
            rides = valueMap.Rides.ToArray();
        }

        public void Start()
        {
            for (int i = 0; i < _valueMap.steps; i++)
            {
                int rangeCounter = 0;
                var available = rides.Where(x => !x.Taken);
                for (int j = 0; j < cars.Length; j++)
                {
                    var current = cars[j];
                    if (current.ride == null || !current.ride.handled && !current.ride.Taken)
                    {
                        var ride = GetBestRide(current, i, ref rangeCounter);
                        if (ride != null)
                        {
                            current.AssignRide(ride);
                            if(!handled.ContainsKey(current.Id))
                            {
                                handled.Add(current.Id, new List<Ride>());
                            }
                            handled[current.Id].Add(ride);
                        }
                    }
                    current.Tick(i);
                }
            }
        }

        private Ride GetBestRide(Car car, int iteration, ref int rangecounter)
        {
            return searchRideRecursive(car, ref rangecounter, null, iteration);
        }

        private Ride searchRideRecursive(Car car,ref int range, Ride ride, int iteration)
        {
            if (ride != null)
                return ride;
            var maxX = car.Position.X + range;
            var minX = car.Position.X - range;
            var minY = car.Position.Y - range;
            var maxY = car.Position.Y + range;
            maxX = maxX >= _valueMap.rows ? _valueMap.rows: maxX;
            minX = minX <= 0 ? 0: maxX;
            minY = minY <= 0 ? 0: minY;
            maxY = maxY >= _valueMap.columns ? _valueMap.columns : maxY;
            var availableRides = new List<Ride>();
            for (int y = minY; y <= maxY ; y++)
            {
                if (y == minY || y == maxY) {
                    for (int x = minX; x <= maxX; x++)
                    {
                        var found = rides.FirstOrDefault(r => r != null &&!r.Taken && !r.handled && r.Start.X == x && r.Start.Y == y);
                        if (found != null)
                        {
                            availableRides.Add(found);
                        }
                    }
                }
                else
                {
                    var found = rides.FirstOrDefault(r => r!= null &&!r.Taken && !r.handled && r.Start.X == minX && r.Start.Y == y);
                    if (found != null)
                        availableRides.Add(found);
                    found = rides.FirstOrDefault(r => r!= null && !r.Taken && !r.handled && r.Start.X == maxX && r.Start.Y == y);
                    if (found != null)
                        availableRides.Add(found);
                }
            }
            if(!availableRides.Any())
            {
                range++;
                return searchRideRecursive(car, ref range, null, iteration);
            }
            range++;
            var ridesss = availableRides.Where(r => r != null && r.EndTick >= iteration + CalculateDistance(r.Start, car.Position));
            return searchRideRecursive(car, ref range, ridesss.OrderBy(r => CalculateDistance(r.Start, car.Position)).FirstOrDefault(), iteration);
        }

        private int CalculateDistance(Point a, Point B)
        {
            var x = a.X - B.X;
            if (x < 0)
                x *= -1;
            var y = a.Y - B.Y;
            if (y < 0)
                y *= -1;
            return x + y;
        }
    }
}
